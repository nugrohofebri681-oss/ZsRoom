# Audit Visual Refinement R2 — wajah/rambut dahulu

7 November 2026. R1/M1/M2 **belum disetujui sebagai model final**. Referensi identitas
tetap konsep empat sudut v2 yang disetujui; bukan foto manusia atau karakter realistis.

| Bagian | Penyebab R1 | Keputusan checkpoint R2 |
| --- | --- | --- |
| Kepala | Sphere sampling jarang, profil pipi/rahang masih kaku | Kepala quad baru dengan profil pipi/muzzle/nose kontinu dan transisi lembut; rasio skull tetap |
| Mata | White/iris/pupil/highlight ellipsoid terpisah di depan permukaan, lash berbentuk tube | Hilangkan seluruh tumpukan itu; gunakan atlas original yang mengikuti UV permukaan kepala untuk eye/lid/lash/highlight |
| Rambut | Curtain terbuka, lobes dangkal, fringe berujung datar/zigzag, global helper membatasi sampling | Buat scalp + swept clumps tertutup, lengkungan keluar–masuk, layer bertingkat, cap ujung membulat dan bangs dari crown |
| Ekspresi | Statis, belum ada face system | Empat preset atlas netral/senyum/mata tertutup/sleepy; identitas dan mesh tetap, bukan facial rig penuh |
| Outfit/body | Kerah/bow/hem/bahu/lengan masih angular, kancing sebagian tertanam | Pertahankan sebagai pembanding, **belum direvisi** pada checkpoint wajah/rambut |
| Skin/corrective | 21 joint, 2 influence; corrective hair/dress baked; fitting kursi belum final | Pertahankan kontrak rig dan clip; regenerate corrective rambut baru lalu audit ulang kontak, tanpa perubahan controller |
| Kontak | Residual tangan/kepala R1 ~7–8 mm | Ukur ulang dengan mesh baru dan tampilkan hasil; belum otomatis tertutup oleh perubahan bentuk |

## Bentuk, topologi dan batas

R2 bukan subdivide R1 atau perubahan lampu. Bagian wajah dan rambut dibangun ulang sebagai
permukaan baru; cahaya, kamera dan tubuh pembanding tetap sama. Atlas dibuat secara parametrik
dari warna/kurva original. Tidak menempelkan pixel concept render pada karakter.

Atlas adalah pilihan stylized yang ringan dan menghilangkan kedalaman palsu/floating dari
stack mata R1. Komprominya: detail eye/lid adalah **paint pada permukaan**, bukan bola mata,
socket dan kelopak berdeformasi dengan facial bones. Empat preset belum merupakan ekspresi
3D/blending atau blink temporal yang natural. Jangan menyebutnya facial rig final.

Hair terdiri dari scalp, 11 kelompok panjang, 5 layer pendek, 7 bangs, 2 face-frame, tuft,
serta pasangan ornamen pink. Root beririsan untuk menutup scalp; bukan topologi rambut tunggal
yang di-weld. Seam/overlap dan penetrasi saat deformasi masih perlu diperiksa artistik.

Checkpoint sementara 17.276 triangle, bukan otomatis sesuai anggaran produksi 10k sebelumnya.
Sampling pertama 21.374 triangle diturunkan, kemudian volume penghubung rambut ditambahkan setelah bentuk dibuat; target berikutnya retopologi
atau LOD setelah persetujuan siluet, bukan mengembalikan bentuk R1. Empat atlas 512² memakai
sekitar 5,33 MiB RGBA+mipmap bila seluruhnya resident; empat material dan dua influence tetap.
Performa fisik A05 belum teruji.

## Urutan lanjutan

1. Review wajah/rambut, empat sudut, ekspresi dan selisih R1 vs R2 pada checkpoint ini.
2. Setelah tanggapan visual, revisi bentuk yang masih kurang; lalu lanjutkan shoulder/hand,
   outfit, kerah/pita/kancing, dress/renda dan material kain.
3. Fitting skin/corrective bed/chair, kontak tangan/kepala, seluruh in-between, lalu uji ulang.
4. Model final dan integrasi kamar tetap memerlukan persetujuan terpisah.

Tidak ada commit, push, merge, PR, deployment, perubahan main atau ekspor GitHub R2.
