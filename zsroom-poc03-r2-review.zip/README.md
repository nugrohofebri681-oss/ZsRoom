# ZsRoom PoC-03 R2 — paket visual review

Status: checkpoint wajah/rambut, **belum model final**. Paket dikemas 9 November 2026 dari
30 PNG original checkpoint 7 November. Tidak ada perubahan model, source, outfit atau kamar.

Buka `index.html` setelah ekstraksi. Jika file manager HP membatasi tautan relatif HTML,
buka PNG langsung dari `images/`. Tidak perlu Node, Blender, game server atau koneksi internet.
Semua gambar mempertahankan byte/resolusi PNG sumber. ZIP memakai kompresi lossless.

- [R1 vs R2](images/00-r1-vs-r2.png)
- [Empat sudut](images/01-four-views.png)
- [Close-up](images/02-face-hair-closeups.png)
- [Preset ekspresi](images/03-expressions.png)
- [Pose/pemeriksaan animasi](images/04-animation-checks.png)
- [Audit triangle/opsi optimasi](TRIANGLE_AUDIT.md)
- [Laporan checkpoint dan hasil tes tersimpan](REPORT.md)
- [Audit refinement checkpoint](AUDIT.md)
- [Manifest internal](review-manifest.json)

Semua panel model adalah capture WebGL aktual, bukan concept render atau hasil retouch.
Pose adalah PNG, bukan rekaman video. Atlas ekspresi belum facial rig/blink temporal penuh.
Source model/GLB/Blender/game tidak dimasukkan. Keterbatasan kontak dan A05 tetap terbuka.
Untuk feedback, sebut nama PNG, bagian yang dinilai, dan prioritas perubahan.
