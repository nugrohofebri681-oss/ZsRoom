> Salinan laporan checkpoint 7 November 2026. Hasil gameplay di bawah adalah hasil tersimpan, bukan rerun saat pengemasan 9 November. Paket ini berisi media review; server studio/source tidak disertakan.

# PoC-03 — Visual Refinement R2, checkpoint wajah/rambut

7 November 2026. **Kandidat untuk review; belum model final.** Pengguna menolak R1/M1/M2 sebagai final. Tahap ini memperbaiki wajah/rambut dahulu, dengan outfit dan tubuh lama tetap agar review terfokus. Tidak ada integrasi kamar atau ekspor GitHub.

## Render aktual

- [R1 vs R2](images/00-r1-vs-r2.png)
- [Empat sudut](images/01-four-views.png)
- [Close-up wajah/rambut](images/02-face-hair-closeups.png)
- [Empat preset ekspresi](images/03-expressions.png)
- [Pose animasi](images/04-animation-checks.png)
- [Galeri lokal](index.html) dan [audit](AUDIT.md)

Semua panel model merupakan capture WebGL mesh aktual tanpa retouch atau beauty render AI. Lampu/kamera pembanding sama. Atlas original dibuat dari kurva/warna, bukan pixel konsep. PNG board hanya komposisi screenshot. Konsep v2 tetap referensi, bukan bukti hasil modeling.

## R1 vs R2

| Bagian | R1 | R2 checkpoint | Masih terbuka |
| --- | --- | --- | --- |
| Kepala | Sphere lebih jarang dan kontur kaku | Quad surface baru dengan pipi/muzzle/nose kontinu | Perlu review kelembutan/profil terhadap konsep |
| Eye/lid/lash/highlight | Stack ellipsoid/tube terangkat dari wajah | Satu atlas mengikuti UV permukaan kepala; objek stack dihapus | Detail painted, belum eye socket/kelopak 3D/facial rig; resolusi close-up terbatas |
| Rambut | Curtain terbuka dan fringe datar | Under-volume tertutup, clumps berkurva berlapis, akar dari crown, ujung membulat | Sambungan/overlap, flow dan deformasi masih belum setara konsep |
| Material wajah/rambut | Vertex color, roughness sederhana | Atlas wajah, perbedaan material kulit/face/hair, lapisan coat rambut ringan | Belum tekstur/roughness art pass final atau SSS; kain tetap R1 |
| Ekspresi | Statis | Empat preset netral/senyum/mata tertutup/sleepy pada satu mesh | Belum blink temporal, blending atau facial rig penuh |
| Tubuh/outfit | Bahu/tangan/kerah/bow/hem masih sederhana | 45 bagian body/outfit terbukti identik | Seluruh refinement body/outfit masih tahap setelah review ini |
| Rig/animasi | Core21 dan controller 02.3 | Kontrak/clip sama, corrective rambut baru dibake offline | Fitting chair/bed dan kontak belum final |

## Ukuran dan anggaran sementara

- 17,276 triangle / 8,906 vertex / 4 material / maksimum 2 influence.
- Rasio terukur 4.749999 kepala; skull top/chin 1.5700001/1.2394737 m. Hair/tuft dikecualikan. Skala teknis 1,57 m bukan tinggi personal.
- Empat atlas 512², sekitar 5,33 MiB RGBA+mip resident; ini tambahan terhadap mesh, morph, skeleton dan framebuffer.
- **Melebihi sasaran karakter awal 10k triangle.** Batas validator 18k adalah ceiling checkpoint review, bukan perubahan standar produksi. Perlu retopologi/LOD setelah siluet disetujui.
- Tidak ada hasil FPS/thermal/memory fisik Samsung A05. Clock sintetis capture/regresi bukan benchmark perangkat.

## Hasil pemeriksaan

- TypeScript strict dan lint studio: lulus.
- Build studio produksi terpisah `character-lab/dist-r2`: lulus; warning chunk >500 kB masih ada.
- Unit baseline: 41/41 lulus. Source kamar/animator lama identik; sebelas tes browser kamar historis tidak diklaim sebagai rerun baru.
- Browser studio: 7 kelompok lulus, 0 page error. Cakupan: R2/Core21 render, idle/walk/collision, bed sit/lie/wake/stand, two chairs/activity/stand, partial recline cancellation, four expression presets / quality resources, portrait layout.
- Production smoke: viewport 1366×900 dan 360×800, empat ekspresi, lima hash aset dan fallback R1 lulus; tidak ada overflow UI atau page error.
- Galeri: lima board decode, 28 tautan HTTP 200 pada kedua viewport, tanpa overflow atau page error.
- Preset ekspresi serta siklus kualitas tidak menambah jumlah resource scene setelah kembali. Ini bukan pembuktian bebas memory leak jangka panjang.
- Geometri/weights/normals/UV finite, sole Y=0, rig SHA/order, GLB Core21 dan kesetaraan body/outfit: lulus.

## Kontak / deformasi yang teramati

Audit vertex terhadap envelope fixture; bukan triangle collision, self-intersection atau pengukuran kontak seluruh frame. Tidak mengklaim clipping sudah bersih.

| Sampel | Kedalaman maksimum | Bagian terburuk |
| --- | ---: | --- |
| seated | 0.00 mm | — |
| edge-seat | 0.00 mm | — |
| hip-settle | 0.00 mm | — |
| hand-support | 7.33 mm | thumb.L |
| back-lower | 5.61 mm | thumb.L |
| first-leg | 0.00 mm | — |
| second-leg | 0.00 mm | — |
| back-settle | 0.00 mm | — |
| pillow | 0.00 mm | — |
| supine-rest | 24.00 mm | r2-layer-2 |
| supine | 24.00 mm | r2-layer-2 |
| wake-mid | 6.08 mm | thumb.L |

Rambut baru menggunakan skin dan corrective offline, bukan cloth simulation. Nilai kecil pun tidak menutup seam, silhouette collapse atau floating; nilai besar memerlukan fitting setelah bentuk disetujui. Kontak tangan/kepala dan chair corrective tidak direvisi pada checkpoint ini.

## Cara menjalankan / melanjutkan

Lihat [petunjuk paket media](README.md). Di cloud saat ini preview produksi lokal memakai `http://127.0.0.1:4186/?model=r2`; URL itu bukan localhost laptop/HP pengguna dan belum URL publik. PNG tersedia untuk review di obrolan. Tidak menawarkan ZIP lokal sebagai unduhan eksternal.

1. Tinjau wajah, ukuran/bentuk eye, flow poni, massa/layer/ujung rambut dan dua ornamen.
2. Berikan koreksi bentuk sebelum lanjut outfit/body. R1 dan ekspornya tetap tersedia.
3. Setelah review: shoulder/hand/sleeve/collar/bow/buttons/dress/renda + material kain; lalu skinning dan corrective bed/chair, kontak serta in-between.
4. Facial animation matang, retopologi/LOD dan pengujian fisik A05 sebelum status final/integrasi.

Integritas: 458 file legacy/core/R1/build/artefak lama tetap identik; branch/HEAD sama. Tidak ada commit, push, merge, PR, deployment atau ekspor R2. Persetujuan ekspor R1 tidak digunakan ulang.
