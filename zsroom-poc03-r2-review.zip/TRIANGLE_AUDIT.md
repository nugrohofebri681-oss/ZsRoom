# Audit triangle PoC-03 R2 — 9 November 2026

Audit dilakukan tanpa mengubah model. Angka dihitung dari indeks segitiga mesh native yang dipakai viewer, bukan jumlah polygon/quads Blender atau jumlah objek. Seluruh triangle dipetakan ke rentang vertex part; jumlah tiap part/material cocok dengan metadata. Tidak ada triangle lintas part.

SHA-256 model R2: `01ba78e10bb78ca730a74c4e5d250a660381d82124a273b42b95ca1f77db4292`.

## Per material R2

| Material | Triangle | Persentase model | Vertex |
| --- | ---: | ---: | ---: |
| skin | 1,216 | 7.04% | 646 |
| hair | 8,592 | 49.73% | 4,382 |
| cloth | 4,668 | 27.02% | 2,476 |
| face | 2,800 | 16.21% | 1,402 |
| **Total** | **17,276** | **100%** | **8,906** |

Vertex adalah jumlah buffer per material setelah ekspor, bukan jumlah titik unik lintas semua objek. Empat material tetap; 28 part hair dibatch menjadi satu mesh/material hair, bukan 28 draw call. Shadow pass dapat menambah draw call.

## Rambut terukur

| Kelompok | Part | Triangle | Persentase hair |
| --- | ---: | ---: | ---: |
| Scalp | 1 | 640 | 7.45% |
| Volume penghubung | 1 | 1,156 | 13.45% |
| 11 helai panjang | 11 | 3,146 | 36.62% |
| 5 layer pendek | 5 | 1,270 | 14.78% |
| 7 poni | 7 | 1,554 | 18.09% |
| 2 pembingkai wajah | 2 | 636 | 7.40% |
| Tuft | 1 | 190 | 2.21% |
| **Total hair** | **28** | **8,592** | **100%** |

Hair adalah **49.73%** model. Ornamen pink dan ribbon memakai material cloth: tambahan **1,324 triangle**, tidak dimasukkan dua kali ke total hair. Hair + aksesori tersebut berjumlah 9,916 triangle.

## Selisih R1 → R2

R1 9,972 → R2 17,276: +7,304 triangle (73.25%). Material hair R1 berjumlah 3,136; R2 8,592. Klasifikasi juga berubah: R1 memiliki eye geometry dan lash/brow pada grup terpisah, sedangkan R2 memakai atlas pada face. Karena itu, selisih material tidak dianggap perbandingan topologi bagian yang identik.

## Opsi optimasi — belum diterapkan

| Kandidat | Dasar perhitungan | Penghematan teoritis | Syarat visual |
| --- | --- | ---: | --- |
| Sampling lintasan 11 helai panjang | 18 → 14 segmen; 8 sisi; T=16s−2 per helai | 704 triangle | Hapus ring pada bagian lurus; pertahankan ring ujung, akar, dan belokan; uji ulang skin/morph |
| Sampling scalp | 32 → 24 kolom, 10 baris; T=2×kolom×baris | 160 triangle | Pertahankan lengkung crown, tepi poni/temple dan transisi normal |
| Sampling volume penghubung | 28 → 24 kolom, 9 baris; dua shell tertutup + rim | 160 triangle | Jangan membuka celah rambut yang sudah ditutup R2; uji semua pose |

Ketiga skenario menghasilkan penghematan aritmetis 1.024 triangle: 17,276 → 16,252 (sekitar 5.93% model). Ini **bukan model hasil optimasi**; penghematan nyata dan kesamaan siluet belum dibuktikan. Angka tidak mencakup perubahan normal/UV/skin/corrective akibat retopologi.

Opsi lanjutan: hapus hanya face yang terbukti selalu tertutup pada scalp/under-volume; sederhanakan penampang helai interior; bake detail helai kecil ke texture/normal; sediakan LOD jarak gameplay dengan model penuh untuk close-up. Jangan menghapus under-volume atau meratakan kontur demi target angka. Keterlihatan dapat berubah saat duduk/rebahan.

Sasaran awal sekitar 10k belum terpenuhi. Tiga skenario konservatif di atas belum cukup; target 10k memerlukan retopologi/LOD lebih luas setelah persetujuan visual. Tidak menjanjikan penghematan tanpa perubahan siluet hanya berdasarkan hitungan triangle.

Gerbang penerimaan optimasi: perbandingan kamera sama pada depan/samping/tiga perempat/belakang, close-up poni/ujung, walk/sit/lie/wake, normal/seam, kontak, skin/morph dan profil fisik A05. Siluet seluruh pose harus tetap diterima sebelum varian menggantikan R2. Sesi ini tidak memproduksi varian tersebut.

## Rincian setiap part hair

| Part | Vertex | Triangle |
| --- | ---: | ---: |
| `r2-scalp` | 352 | 640 |
| `r2-under-volume` | 580 | 1,156 |
| `r2-long-clump-0` | 145 | 286 |
| `r2-long-clump-1` | 145 | 286 |
| `r2-long-clump-2` | 145 | 286 |
| `r2-long-clump-3` | 145 | 286 |
| `r2-long-clump-4` | 145 | 286 |
| `r2-long-clump-5` | 145 | 286 |
| `r2-long-clump-6` | 145 | 286 |
| `r2-long-clump-7` | 145 | 286 |
| `r2-long-clump-8` | 145 | 286 |
| `r2-long-clump-9` | 145 | 286 |
| `r2-long-clump-10` | 145 | 286 |
| `r2-layer-0` | 129 | 254 |
| `r2-layer-1` | 129 | 254 |
| `r2-layer-2` | 129 | 254 |
| `r2-layer-3` | 129 | 254 |
| `r2-layer-4` | 129 | 254 |
| `r2-bang-0` | 113 | 222 |
| `r2-bang-1` | 113 | 222 |
| `r2-bang-2` | 113 | 222 |
| `r2-bang-3` | 113 | 222 |
| `r2-bang-4` | 113 | 222 |
| `r2-bang-5` | 113 | 222 |
| `r2-bang-6` | 113 | 222 |
| `r2-face-frame--1` | 161 | 318 |
| `r2-face-frame-1` | 161 | 318 |
| `r2-tuft` | 97 | 190 |

## Keterbatasan checkpoint yang tetap berlaku

Rasio sekitar 4,75 kepala dan rig 21 joint dipertahankan. Empat preset ekspresi adalah atlas, bukan facial rig/blink temporal matang. Audit kontak checkpoint masih mencatat sekitar 24 mm penetrasi rambut dan 7,3 mm ibu jari terhadap envelope fixture. Tidak diperbaiki dalam pekerjaan pengemasan. Performa Samsung A05 belum diverifikasi secara fisik.
