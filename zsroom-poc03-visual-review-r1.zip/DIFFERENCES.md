# Perbedaan konsep yang disetujui vs model aktual M1/M2

Status: **untuk review; model belum final**. Paket ini tidak memperbaiki atau mengganti model.
Acuan adalah `images/00-concept-approved.png`; seluruh gambar “Actual WebGL” berasal dari mesh
M1/M2 yang sama. Perbedaan di bawah diamati pada PNG close-up, bukan disimpulkan dari jumlah
triangle atau kelulusan test.

Identitas dasarnya sudah diikuti: rambut cokelat panjang dan poni, dua ornamen pink, mata cokelat,
outfit pink dengan detail putih. Rasio geometri 4,75 kepala telah diukur pada milestone sebelumnya.
**Kualitas bentuk dan material aktual belum menyamai konsep yang disetujui.**

| Bagian | Konsep disetujui | Terlihat pada model aktual | Bukti utama |
| --- | --- | --- | --- |
| Wajah | Pipi/rahang lembut, volume menyatu, kesan hangat | Kontur rahang/pipi masih bersegi pada close-up; shading lebih datar | `10-face-front.png`, `11-face-three-quarter.png` |
| Mata/kelopak | Mata cokelat lembut, kelopak dan lash menyatu dengan wajah | Mata lebih bulat, putih mata/outline tampak seperti cincin terpisah; dari samping/rebahan mata dan lash terlihat menonjol/terangkat dari volume wajah. Kelopak belum matang; highlight bersegi | `10-face-front.png` |
| Ekspresi | Netral/senyum lembut dengan wajah ekspresif | Mulut/ekspresi masih statis; blink dan facial expression belum dibuat | `06-idle.png`, video idle/walk |
| Scalp/poni | Kelompok rambut dengan arah, volume dan pertemuan yang halus | Cap dan fringe masih tampak seperti permukaan besar terpisah; batas poni zigzag dan beberapa seam terlihat | `10-face-front.png`, `13-hair-side.png` |
| Rambut panjang | Kelompok helai melengkung, flow dan ujung membulat berlapis | Massa belakang lebih menyerupai curtain/pita tebal; helai relatif lurus, beberapa ujung/kontur masih tajam atau datar | `12-hair-back.png`, `13-hair-side.png` |
| Ornamen pink | Bentuk kecil membulat, menyatu dengan rambut | Warna/jumlah terjaga, tetapi petal/ribbon lebih sederhana dan bersudut | Close-up wajah/rambut |
| Siluet tubuh | Chibi sekitar 4,75 kepala, anggota tubuh lembut | Rasio diikuti, tetapi lengan/torso/kaki lebih lurus dan tubular; volume bahu belum sehalus konsep | `02-front.png`, `03-side.png` |
| Sambungan bahu/sleeve | Kain mengalir dari shoulder ke lengan | Batas sambungan dan bentuk shoulder/sleeve tampak terpisah/bersudut | `14-outfit-upper.png` |
| Kerah/bow/kancing | Kerah putih membulat, bow lembut, placket/kancing terbaca | Kerah/bow masih polygonal; sebagian kancing tampak kecil/terpotong atau tertanam pada placket—perlu pemeriksaan geometri/occlusion | `14-outfit-upper.png` |
| Dress/hem | A-line ringan, lipatan dan frill putih lembut | Permukaan dress lebih kaku/lurus; hem tipis berlekuk dan belum menyerupai frill kain lembut | `15-outfit-hem.png` |
| Material | Soft matte dengan variasi permukaan dan highlight terarah | Warna umum terjaga, tetapi hasil studio lebih datar; pemisahan rambut/katun/kulit kurang matang | Semua close-up |
| Socks/shoes | Bentuk rounded dengan detail kain dan strap yang lembut | Identitas warna/garis/strap terjaga; tepi sepatu/detail masih sederhana dan bersegi | `16-socks-shoes.png` |
| Duduk/rebahan | Konsep tidak menyediakan deformasi produksi lengkap | Skin/shape key sudah mengikuti rig; rambut/dress berubah bentuk, tetapi lipatan, volume dan kontak masih perlu dinilai visual | `17`–`25`, video kasur |

Perbandingan warna bukan pengujian color-match terkalibrasi: konsep adalah gambar generatif
bergaya render, sedangkan model memakai material/lampu studio aktual. Namun perbedaan bentuk,
seam, keterpisahan mata, shoulder dan detail outfit tetap perlu ditinjau; jangan menyalahkan
seluruh selisih pada pencahayaan.

## Deformasi dan kontak yang belum ditutup

- Pair `20/21` dan `22/23` menunjukkan corrective **ON/OFF** pada pose duduk/telentang yang sama.
  OFF adalah kontrol perbandingan, bukan versi model baru atau tampilan default produksi.
- Rambut/dress tidak lagi hanya menempel kaku pada root, tetapi bentuk setelah deformasi belum
  otomatis terlihat natural. Perhatikan penumpukan massa rambut, ketebalan hem dan volume kain.
- Pengujian M1/M2 yang tersimpan sebelumnya melaporkan residual envelope sekitar **7,36 mm**
  pada ibu jari dan **7,60 mm** pada belakang kepala/bantal. Paket ini memperlihatkan area
  kontak tersebut, tetapi tidak mengubah atau mengklaim menutup isu itu.
- Corrective saat ini ditujukan ke bed; fitting khusus kursi, self-intersection penuh dan
  kontak seluruh frame belum final. Pose duduk dalam paket utama adalah duduk di tepi kasur.
- Angka 4,75 kepala adalah hasil ukur mesh M1/M2 (tanpa rambut/tuft), bukan bukti seluruh
  detail wajah atau proporsi visual sudah sama dengan gambar konsep.

## Poin keputusan pengguna

1. Apakah bentuk wajah/mata dan poni masih terasa sebagai Zila, atau bagian mana yang perlu
   mendekati konsep lebih jauh?
2. Apakah rambut perlu lebih melengkung/berlapis dan ujungnya lebih bulat?
3. Apakah siluet dress, shoulder, collar/bow/hem sudah sesuai arah yang diinginkan?
4. Apakah material perlu lebih lembut dan hangat pada jarak gameplay maupun close-up?
5. Bagian mana yang paling mengganggu saat animasi berjalan, duduk dan rebahan?

Keputusan tersebut menjadi bahan pekerjaan **setelah** review. Tidak ada revisi model,
perubahan rig, perbaikan material atau integrasi kamar dilakukan dalam pembuatan paket ini.
