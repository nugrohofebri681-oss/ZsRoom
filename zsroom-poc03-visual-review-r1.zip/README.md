# ZsRoom PoC-03 — Paket visual review R1

**M1/M2 diterima untuk ditinjau, bukan model final.** Konsep v2 disetujui sebagai acuan; model,
material dan deformasi masih perlu review. Tidak ada perubahan model atau integrasi kamar
ketika menyiapkan paket ini.

## Buka dari laptop / Samsung A05

1. Setelah paket diperoleh, ekstrak ZIP, lalu buka `index.html` untuk galeri lokal.
2. Jika galeri HTML tidak didukung oleh file manager/browser, buka PNG dari folder `images`
   dan MP4 dari folder `videos` secara langsung. Di Samsung, gunakan My Files/Gallery atau Chrome.
3. Semua PNG/MP4 mandiri: tidak perlu Node, Blender, Babylon, GPU game, akun atau server cloud.
   MP4 memakai H.264 Main, 960×720, yuv420p, faststart, tanpa audio.
4. Untuk akses tanpa mengekstrak ZIP, rencana ekspor menyediakan lima lembar PNG dan dua MP4
   langsung di branch artefak GitHub. Ekspor itu belum dilakukan dan menunggu izin pengguna.

Link `/workspace/...` di Codex bukan URL unduhan publik. Paket ini disiapkan agar bisa dibagikan
melalui metode GitHub yang disetujui nanti, tanpa Pages/deployment atau menimpa game lama.

## Mulai dari lima lembar ringkas

- [Konsep vs actual](images/01-comparison.png).
- [Empat sudut](images/27-four-views.png).
- [Idle, walk, sit, supine](images/28-poses.png).
- [Close-up wajah, rambut dan outfit](images/29-closeups.png).
- [Deformasi, ON/OFF dan kontak](images/30-deformation.png).

PNG individual 1600×1200 tersedia untuk zoom/detail, termasuk socks/shoes serta kepala/bantal.
PNG gabungan disusun lewat layout HTML dari sumber asli, tanpa retouch/recolor atau perbaikan
geometri. Beberapa gambar memiliki label viewport; gambar lainnya membaca buffer WebGL secara
langsung. Semua model aktual berasal dari source/mesh M1/M2 yang sama.

## Rekaman pendek

- [Idle → berjalan](videos/01-idle-walk.mp4).
- [Duduk → rebahan → telentang → bangun → berdiri](videos/02-seat-lie-wake.mp4).

Video menangkap renderer/controller/rig asli dengan clock capture 30 sampel/detik. Tidak ada
injeksi pose atau gerakan buatan untuk memperindah model. **30 fps video bukan bukti FPS
browser/performa A05**; pengujian fisik A05 belum dilakukan. Lampu dan profil viewer yang
tersedia dipakai apa adanya: PNG Detail, MP4 Seimbang. Kamera/framing sementara hanya untuk
capture dan tidak disimpan ke source model atau viewer.

## Baca sebelum menilai

[Ringkasan perbedaan](DIFFERENCES.md) mencatat gap wajah/mata, rambut, shoulder/sleeve,
kerah/bow/kancing, hem dan material. Kualitas aktual belum menyamai konsep yang disetujui.
Corrective OFF adalah kontrol perbandingan; tampilan default adalah ON. Kasur merupakan
fixture ukur, bukan desain kamar baru. Residual kontak M1/M2 masih terbuka.

[Format umpan balik](REVIEW_NOTES.md): sebut nama PNG atau MP4 + timestamp dan prioritas revisi.
[Inventaris/checksum paket](review-manifest.json). Tidak ada source model, GLB/Blender, source game,
arsip pribadi atau layanan komunikasi dalam paket visual ini.
