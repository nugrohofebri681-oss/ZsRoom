# Catatan review pengguna — Zila M1/M2

Ini format opsional untuk memudahkan memberi umpan balik; jangan menganggap kolom kosong sebagai persetujuan.

- Perangkat/browser:
- Bagian yang sudah sesuai:
- Bagian yang paling perlu diubah:
- Wajah/mata (file 10/11):
- Rambut/poni/ornamen (file 12/13):
- Outfit/hem/shoes (file 14/15/16):
- Duduk dan rebahan (file 17–25):
- Gerakan pada video (nama video + timestamp):
- Prioritas revisi 1–3:
- Status keputusan: belum disetujui / diterima dengan revisi / disetujui untuk tahap berikutnya.

Contoh: “videos/02-seat-lie-wake.mp4, 00:06 — rambut terlihat menumpuk di bawah kepala;
images/14-outfit-upper.png — sambungan bahu terlalu tajam.”
